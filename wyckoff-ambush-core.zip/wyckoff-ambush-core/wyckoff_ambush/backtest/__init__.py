"""回测工具

组合级资金曲线回测，修正上游 `lianghua` 的收益口径错误。

上游缺陷对照见 `portfolio.py` 模块文档与 `docs/UPSTREAM_AUDIT.md`。
"""
from .order_execution import (
    check_limit_order_fill,
    calc_fill_price_with_slippage,
    DEFAULT_EXECUTION_PARAMS,
)
from .portfolio import (
    CostModel,
    ExitKind,
    Trade,
    EquityPoint,
    BacktestResult,
    PortfolioBacktester,
    DEFAULT_PORTFOLIO_PARAMS,
)

__all__ = [
    "check_limit_order_fill",
    "calc_fill_price_with_slippage",
    "DEFAULT_EXECUTION_PARAMS",
    "CostModel",
    "ExitKind",
    "Trade",
    "EquityPoint",
    "BacktestResult",
    "PortfolioBacktester",
    "DEFAULT_PORTFOLIO_PARAMS",
]