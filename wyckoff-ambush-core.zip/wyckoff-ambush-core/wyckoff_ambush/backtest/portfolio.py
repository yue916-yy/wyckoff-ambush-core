"""
组合级资金曲线回测
==================

本模块存在的唯一理由：**修正上游 `lianghua` 项目的收益计算错误。**

上游问题
--------
1. `compute_metrics` 用 ``sum(t.profit_pct for t in trades)``——把每笔交易的
   百分比收益直接相加，得到所谓的"累计收益"。
2. 再把这个和当作复利基数，开 N 次方根得到"年化收益"。
3. 回测对**每只股票独立分配 10 万初始资金**，跨股票无组合资金约束。

上游报告的"869 笔 × 1.60% = +1388.83% 累计 / 年化 63.40%"
实际是第 1、2 步双重虚构的正确值。但第 3 步意味着真实收益还要再乘以仓位比例
（约 30%），即真实资金曲线收益约为报告值的 1/3。

本模块的修正
------------
- **单一时序资金池**：所有股票共享一个 cash，按时间顺序统一处理信号与持仓
- **组合级资金约束**：同时持仓数受 `max_concurrent_positions` 限制
- **真实复利**：权益变化驱动后续仓位计算
- **真实年化**：按实际天数几何年化，不做二次虚构
- **交易成本**：可配置佣金与印花税

同时修正前视偏差
----------------
上游 T+1 执行块存在三处日内前视：
1. 用 T+1 **全天 ATR**（含收盘）决定 T+1 **开盘**的仓位与止损倍数
2. 限价成交用 T+1 **最低价**判定是否成交
3. 同一根 K 线内先用**最高价**上移吊灯线，再拿当日**收盘价**判是否击穿

本模块约定：**T 日收盘后产生的信号，只使用 T 日及之前的数据做决策，
所有成交假设发生在 T+1。**
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Dict, Iterable, List, Optional

import pandas as pd


# ══════════════════════════════════════════════════════════════════════
#  交易成本模型
# ══════════════════════════════════════════════════════════════════════

@dataclass
class CostModel:
    """A 股交易成本

    默认值参照主流券商公开费率与 2023-08 印花税下调后的水平：
    - 佣金：万 2.5，双边收取，最低 5 元
    - 印花税：千 1，**仅卖出收取**
    - 过户费：十万分之 1（沪市 historically，深市已并入佣金）

    上游项目**未扣除任何交易成本**，其 README 自述 869 笔估算费用约 -30%，
    即原始业绩还要打七折。
    """

    commission_rate: float = 0.00025   # 佣金费率（万 2.5）
    min_commission: float = 5.0        # 单笔最低佣金
    stamp_tax_rate: float = 0.001      # 印花税（千 1，仅卖出）
    transfer_fee_rate: float = 0.00001 # 过户费

    def buy_cost(self, amount: float) -> float:
        """买入总费用"""
        commission = max(amount * self.commission_rate, self.min_commission)
        transfer = amount * self.transfer_fee_rate
        return commission + transfer

    def sell_cost(self, amount: float) -> float:
        """卖出总费用"""
        commission = max(amount * self.commission_rate, self.min_commission)
        stamp = amount * self.stamp_tax_rate
        transfer = amount * self.transfer_fee_rate
        return commission + stamp + transfer


# ══════════════════════════════════════════════════════════════════════
#  数据结构
# ══════════════════════════════════════════════════════════════════════

class ExitKind(str, Enum):
    """退出原因（沿用上游语义，便于对照其退出分布表）"""

    BREAKEVEN_STOP = "保本止损"
    ATR_HARD_STOP = "硬止损"
    CHANDELIER_EXIT = "吊灯止盈"
    BUY_CLIMAX = "抢购高潮"
    EARLY_EXIT = "快速退出"
    PROFIT_TIER = "档位止盈"
    TIME_STOP = "时间止损"
    MAX_HOLD = "超时平仓"
    SIGNAL = "信号结束"          # 组合回测末尾强制平仓


@dataclass
class Trade:
    """单笔交易记录

    成本字段保留**绝对金额**，用于真实资金曲线；`return_pct` 是该笔的
    相对收益率，仅用于统计胜率——不要用它跨交易相加得到"总收益"。
    """

    ts_code: str
    buy_date: pd.Timestamp
    sell_date: pd.Timestamp
    buy_price: float
    sell_price: float
    shares: int
    hold_days: int
    cost_basis: float             # 含买入费用的总投入
    proceeds: float               # 扣除卖出费用的净回款
    exit_reason: ExitKind
    gross_return_pct: float = 0.0  # 毛收益率
    net_return_pct: float = 0.0    # 净收益率（扣费用）
    max_profit_pct: float = 0.0

    @property
    def net_pnl(self) -> float:
        """净盈亏金额"""
        return self.proceeds - self.cost_basis


@dataclass
class EquityPoint:
    date: pd.Timestamp
    equity: float
    cash: float
    position_value: float
    drawdown: float


@dataclass
class BacktestResult:
    """回测结果

    **所有收益指标均基于真实资金曲线**，可直接解读。
    """

    trades: List[Trade]
    equity_curve: List[EquityPoint]
    initial_cash: float
    final_equity: float
    params: Dict[str, Any] = field(default_factory=dict)

    # ── 基础统计 ──
    @property
    def total_trades(self) -> int:
        return len(self.trades)

    @property
    def win_rate(self) -> float:
        """胜率（%）：净收益 > 0 的交易占比"""
        if not self.trades:
            return 0.0
        wins = [t for t in self.trades if t.net_pnl > 0]
        return len(wins) / len(self.trades) * 100

    @property
    def avg_hold_days(self) -> float:
        if not self.trades:
            return 0.0
        return sum(t.hold_days for t in self.trades) / len(self.trades)

    # ── 真实资金曲线口径 ──
    @property
    def total_return_pct(self) -> float:
        """累计收益率（%）= 期末权益 / 期初权益 - 1

        这是唯一正确的"总收益"口径。
        """
        if self.initial_cash <= 0:
            return 0.0
        return (self.final_equity / self.initial_cash - 1) * 100

    @property
    def annualized_return_pct(self) -> float:
        """几何年化收益率（%）

        按资金曲线的真实起止日期计算，**不是**对"百分比之和"再开方根。
        """
        if len(self.equity_curve) < 2:
            return 0.0
        days = (self.equity_curve[-1].date - self.equity_curve[0].date).days
        if days <= 0:
            return 0.0
        years = days / 365.25
        if self.initial_cash <= 0 or self.final_equity <= 0:
            return -100.0
        growth = self.final_equity / self.initial_cash
        return (math.pow(growth, 1 / years) - 1) * 100

    @property
    def max_drawdown_pct(self) -> float:
        """最大回撤（%），基于资金曲线

        drawdown 记为**负值**（如 -18.42），因此取最小值才是最大回撤。
        """
        if not self.equity_curve:
            return 0.0
        return min(p.drawdown for p in self.equity_curve)

    @property
    def sharpe(self) -> float:
        """年化夏普比率（无风险利率取 0）"""
        if len(self.equity_curve) < 3:
            return 0.0
        rets = pd.Series([p.equity for p in self.equity_curve]).pct_change().dropna()
        if rets.std() == 0:
            return 0.0
        return float(rets.mean() / rets.std() * math.sqrt(252))

    @property
    def profit_factor(self) -> float:
        """盈亏比（总盈利额 / 总亏损额绝对值）"""
        wins = sum(t.net_pnl for t in self.trades if t.net_pnl > 0)
        losses = abs(sum(t.net_pnl for t in self.trades if t.net_pnl <= 0))
        if losses == 0:
            return float("inf") if wins > 0 else 0.0
        return wins / losses

    @property
    def exit_distribution(self) -> Dict[str, int]:
        dist: Dict[str, int] = {}
        for t in self.trades:
            key = t.exit_reason.value
            dist[key] = dist.get(key, 0) + 1
        return dict(sorted(dist.items(), key=lambda kv: -kv[1]))

    def summary(self) -> str:
        lines = [
            "─" * 62,
            f"  组合级回测结果（真实资金曲线）",
            "─" * 62,
            f"  期初权益        {self.initial_cash:>14,.2f}",
            f"  期末权益        {self.final_equity:>14,.2f}",
            f"  累计收益率      {self.total_return_pct:>+14.2f}%",
            f"  年化收益率      {self.annualized_return_pct:>+14.2f}%",
            f"  最大回撤        {self.max_drawdown_pct:>14.2f}%",
            f"  夏普比率        {self.sharpe:>14.2f}",
            "─" * 62,
            f"  交易笔数        {self.total_trades:>14d}",
            f"  胜率            {self.win_rate:>14.2f}%",
            f"  盈亏比          {self.profit_factor:>14.2f}",
            f"  平均持仓        {self.avg_hold_days:>14.2f} 天",
            "─" * 62,
            f"  总盈亏金额      {sum(t.net_pnl for t in self.trades):>+14,.2f}",
            f"  总交易费用      {sum(self._trade_fee(t) for t in self.trades):>14,.2f}",
            "─" * 62,
            "  退出分布:",
        ]
        for reason, count in self.exit_distribution.items():
            lines.append(f"    {reason:<12} {count:>5d} 笔")
        lines.append("─" * 62)
        return "\n".join(lines)

    @staticmethod
    def _trade_fee(t: Trade) -> float:
        return (t.cost_basis - t.buy_price * t.shares) + (
            t.sell_price * t.shares - t.proceeds
        )


# ══════════════════════════════════════════════════════════════════════
#  组合级回测引擎
# ══════════════════════════════════════════════════════════════════════

DEFAULT_PORTFOLIO_PARAMS: Dict[str, Any] = {
    # ── 资金 ──
    "initial_cash": 100_000.0,
    "max_concurrent_positions": 5,      # 同时最多持仓数
    "max_position_pct": 0.20,           # 单只最大仓位占总权益比例

    # ── 入场 ──
    "entry_quality_min_score": 4,       # 与实盘 daily_push.py:63 对齐
    "limit_order_enabled": False,       # 上游实测难以建模，默认关闭

    # ── 退出 ──
    "hard_stop_atr": 2.5,
    "chandelier_atr_mult": 3.0,
    "breakeven_trigger_pct": 0.05,
    "breakeven_min_profit_pct": 0.003,
    "max_hold_days": 15,
    "time_stop_days": 10,
    "profit_tier_enabled": True,

    # ── 成本 ──
    "cost_model": CostModel(),
}


@dataclass
class _OpenPosition:
    ts_code: str
    buy_date: pd.Timestamp
    buy_price: float
    shares: int
    atr_at_entry: float
    chandelier_mult: float
    hard_stop_mult: float
    peak_price: float
    hold_days: int = 0

    @property
    def stop_price(self) -> float:
        """吊灯止损价（随最高价上移）"""
        return self.peak_price - self.chandelier_mult * self.atr_at_entry

    @property
    def max_profit_pct(self) -> float:
        return (self.peak_price - self.buy_price) / self.buy_price


class PortfolioBacktester:
    """组合级回测引擎

    与上游 `StatefulTradeBacktester_V64` 的关键差异：

    | 维度           | 上游                                | 本实现                    |
    |----------------|-------------------------------------|---------------------------|
    | 资金池         | 每只股票独立 10 万                  | 全部股票共享一个 cash      |
    | 同时持仓       | 无约束                              | `max_concurrent_positions` |
    | 仓位基准       | `initial_cash`（恒定）              | 当前总权益（真实复利）    |
    | 收益口径       | `sum(profit_pct)`                   | 期末权益 / 期初权益        |
    | 年化           | 对百分比和开方根                     | 资金曲线几何年化           |
    | 交易成本       | 无                                  | `CostModel` 双边扣除       |
    | T+1 前视       | 用当日收盘 ATR 决定当日开盘仓位       | 只用 T 日及之前数据决策     |

    用法
    ----
    >>> import pandas as pd
    >>> from wyckoff_ambush import IndicatorCalcBase, Detect_AmbushSignal_V64, V64_PARAMS
    >>> from wyckoff_ambush.backtest import PortfolioBacktester
    >>>
    >>> # price_data: {ts_code: DataFrame[Open/High/Low/Close/Volume], DatetimeIndex}
    >>> prepared = {}
    >>> for code, df in price_data.items():
    ...     d = IndicatorCalcBase(df)
    ...     d = Detect_AmbushSignal_V64(d, V64_PARAMS)
    ...     prepared[code] = d
    >>>
    >>> bt = PortfolioBacktester(params={...})
    >>> result = bt.run(prepared, start="2021-01-01", end="2024-12-31")
    >>> print(result.summary())
    """

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        self.params = {**DEFAULT_PORTFOLIO_PARAMS, **(params or {})}

    # ──────────────────────────────────────────────────────────────────
    #  主流程
    # ──────────────────────────────────────────────────────────────────
    def run(
        self,
        prepared: Dict[str, pd.DataFrame],
        start: Optional[str] = None,
        end: Optional[str] = None,
        benchmark: Optional[pd.Series] = None,
    ) -> BacktestResult:
        """执行组合回测

        Args:
            prepared: {ts_code: 已计算指标的 DataFrame}
            start: 回测起始日（含），None 为最早
            end: 回测结束日（含），None 为最晚
            benchmark: 基准净值序列（可选，用于算超额）
        """
        cash = float(self.params["initial_cash"])
        max_pos = int(self.params["max_concurrent_positions"])
        max_pct = float(self.params["max_position_pct"])
        cost = self.params["cost_model"]

        positions: Dict[str, _OpenPosition] = {}
        trades: List[Trade] = []
        equity_curve: List[EquityPoint] = []
        peak_equity = cash
        pending: List[tuple] = []          # (ts_code, signal_date) 待次日开盘执行

        # 汇总所有股票的交易日并集，构造统一时序
        all_dates = self._build_timeline(prepared, start, end)
        if not all_dates:
            return BacktestResult([], [], cash, cash, self.params)

        # 预先建立 (ts_code, date) -> 行 的索引，避免循环内重复 loc
        rows_index: Dict[str, pd.Series] = {}
        for code, df in prepared.items():
            rows_index[code] = df

        for date in all_dates:
            # ── 1. 执行昨日挂单的今日开盘买入 ──
            for signal_code, _sig_date in pending:
                if signal_code in positions or len(positions) >= max_pos:
                    continue
                pos = self._try_buy(
                    signal_code, date, rows_index, cash, max_pct
                )
                if pos is not None:
                    cash -= pos["cash_out"]
                    positions[signal_code] = pos["position"]
            pending.clear()

            # ── 2. 持仓盯市与退出 ──
            for code, pos in list(positions.items()):
                df = prepared.get(code)
                if df is None or date not in df.index:
                    # 停牌：不更新峰值（无当日价格），留待复牌或收尾处理
                    continue

                row = df.loc[date]
                close = float(row["Close"])
                atr = float(row.get("atr14", pos.atr_at_entry))

                pos.hold_days += 1
                # 峰值只用**当日及之前**的最高价（不跨到未来）
                pos.peak_price = max(pos.peak_price, float(row["High"]))

                exit_reason = self._check_exit(pos, row, close, atr)
                if exit_reason is not None:
                    fill = self._sell_price(pos, row, close)
                    gross = fill * pos.shares
                    proceeds = gross - cost.sell_cost(gross)
                    cash += proceeds
                    buy_gross = pos.buy_price * pos.shares
                    trades.append(
                        Trade(
                            ts_code=code,
                            buy_date=pos.buy_date,
                            sell_date=date,
                            buy_price=round(pos.buy_price, 3),
                            sell_price=round(fill, 3),
                            shares=pos.shares,
                            hold_days=pos.hold_days,
                            cost_basis=round(buy_gross + cost.buy_cost(buy_gross), 2),
                            proceeds=round(proceeds, 2),
                            exit_reason=exit_reason,
                            gross_return_pct=round(
                                (fill - pos.buy_price) / pos.buy_price * 100, 2
                            ),
                            net_return_pct=round(
                                (proceeds - (buy_gross + cost.buy_cost(buy_gross)))
                                / (buy_gross + cost.buy_cost(buy_gross)) * 100,
                                2,
                            ),
                            max_profit_pct=round(pos.max_profit_pct * 100, 2),
                        )
                    )
                    del positions[code]

            # ── 权益曲线打点 ──
            # 关键：必须在全部买卖完成后重算，否则卖出时 cash 增加而
            # equity 未同步，导致权益曲线出现虚假断层。
            pos_value = 0.0
            for code, pos in positions.items():
                df = prepared.get(code)
                if df is None or date not in df.index:
                    # 停牌：按峰值（最后已知价）计市值，避免虚增
                    pos_value += pos.shares * pos.peak_price
                else:
                    pos_value += pos.shares * float(df.loc[date, "Close"])

            equity = max(cash + pos_value, 1e-9)
            peak_equity = max(peak_equity, equity)
            drawdown = (equity / peak_equity - 1) * 100
            equity_curve.append(
                EquityPoint(
                    date=date,
                    equity=round(equity, 2),
                    cash=round(cash, 2),
                    position_value=round(pos_value, 2),
                    drawdown=round(drawdown, 2),
                )
            )

            # ── 3. 扫描今日收盘信号，排队到明日开盘执行 ──
            # 关键：此处只读取**今日及之前**的列，不含未来信息
            min_score = int(self.params["entry_quality_min_score"])
            for code, df in prepared.items():
                if code in positions or len(positions) + len(pending) >= max_pos:
                    continue
                if date not in df.index:
                    continue
                row = df.loc[date]
                if not bool(row.get("ambush_signal", False)):
                    continue
                score = int(row.get("entry_quality_score", 0) or 0)
                if score < min_score:
                    continue
                pending.append((code, date))

        # ── 4. 收尾：强制平掉剩余持仓 ──
        if positions:
            last_date = all_dates[-1]
            for code, pos in positions.items():
                df = prepared[code]
                close = float(df.loc[last_date, "Close"])
                gross = close * pos.shares
                proceeds = gross - cost.sell_cost(gross)
                buy_gross = pos.buy_price * pos.shares
                cash += proceeds
                trades.append(
                    Trade(
                        ts_code=code,
                        buy_date=pos.buy_date,
                        sell_date=last_date,
                        buy_price=round(pos.buy_price, 3),
                        sell_price=round(close, 3),
                        shares=pos.shares,
                        hold_days=pos.hold_days,
                        cost_basis=round(buy_gross + cost.buy_cost(buy_gross), 2),
                        proceeds=round(proceeds, 2),
                        exit_reason=ExitKind.SIGNAL,
                        gross_return_pct=round(
                            (close - pos.buy_price) / pos.buy_price * 100, 2
                        ),
                        net_return_pct=round(
                            (proceeds - (buy_gross + cost.buy_cost(buy_gross)))
                            / (buy_gross + cost.buy_cost(buy_gross)) * 100,
                            2,
                        ),
                        max_profit_pct=round(pos.max_profit_pct * 100, 2),
                    )
                )

        final_equity = equity_curve[-1].equity if equity_curve else cash
        return BacktestResult(
            trades=trades,
            equity_curve=equity_curve,
            initial_cash=float(self.params["initial_cash"]),
            final_equity=round(final_equity, 2),
            params=self.params,
        )

    # ──────────────────────────────────────────────────────────────────
    #  内部方法
    # ──────────────────────────────────────────────────────────────────
    @staticmethod
    def _build_timeline(
        prepared: Dict[str, pd.DataFrame],
        start: Optional[str],
        end: Optional[str],
    ) -> List[pd.Timestamp]:
        """构造所有股票的交易日并集（升序、去重）"""
        idx: List[pd.Timestamp] = []
        for df in prepared.values():
            if df is None or len(df) == 0:
                continue
            idx.extend(df.index.tolist())
        if not idx:
            return []
        uniq = sorted(set(idx))
        if start:
            uniq = [d for d in uniq if d >= pd.Timestamp(start)]
        if end:
            uniq = [d for d in uniq if d <= pd.Timestamp(end)]
        return uniq

    def _try_buy(
        self,
        code: str,
        date: pd.Timestamp,
        rows_index: Dict[str, pd.DataFrame],
        cash: float,
        max_pct: float,
    ) -> Optional[dict]:
        """T+1 开盘买入

        只用**当日开盘价**成交，不看当日收盘/最低/最高——杜绝日内前视。
        """
        df = rows_index.get(code)
        if df is None or date not in df.index:
            return None
        row = df.loc[date]

        open_p = float(row["Open"])
        if open_p <= 0:
            return None

        # 防高开跳空：开盘价高于信号日收盘 +1.5×ATR 则放弃
        prev_pos = df.index.get_loc(date)
        if prev_pos > 0:
            prev = df.iloc[prev_pos - 1]
            prev_close = float(prev["Close"])
            prev_atr = float(prev.get("atr14", float("nan")))
            if prev_atr == prev_atr and prev_atr > 0:      # NaN-safe
                if open_p > prev_close + 1.5 * prev_atr:
                    return None
            # 防破位：开盘跌破信号日均线托底位则放弃
            if "yellow_line" in prev.index:
                prev_yellow = float(prev["yellow_line"])
                if prev_yellow == prev_yellow and open_p < prev_yellow:
                    return None

        # 仓位：当前权益 × max_pct（真实复利，非 initial_cash）
        atr = float(row.get("atr14", prev_atr if prev_pos > 0 else 0.0))
        if atr != atr or atr <= 0:
            return None
        hard_mult = float(self.params["hard_stop_atr"])

        risk_budget = cash * 0.01                      # 单笔风险 1%
        per_share_loss = hard_mult * atr
        if per_share_loss <= 0:
            return None
        risk_shares = risk_budget / per_share_loss
        cap_shares = int((cash * max_pct) / open_p / 100) * 100
        shares = int(min(risk_shares, cap_shares) / 100) * 100
        if shares <= 0:
            return None

        gross = open_p * shares
        cost = self.params["cost_model"]
        total_out = gross + cost.buy_cost(gross)
        if total_out > cash:
            shares = int((cash * 0.95) / open_p / 100) * 100
            if shares <= 0:
                return None
            gross = open_p * shares
            total_out = gross + cost.buy_cost(gross)

        return {
            "cash_out": total_out,
            "position": _OpenPosition(
                ts_code=code,
                buy_date=date,
                buy_price=open_p,
                shares=shares,
                atr_at_entry=atr,
                chandelier_mult=float(self.params["chandelier_atr_mult"]),
                hard_stop_mult=hard_mult,
                peak_price=float(row["High"]),   # 建仓当日最高价（当日可得）
            ),
        }

    def _check_exit(
        self,
        pos: _OpenPosition,
        row: pd.Series,
        close: float,
        atr: float,
    ) -> Optional[ExitKind]:
        """退出判定

        顺序按上游 V6.4 语义：保本 → 硬止损 → 吊灯 → 档位 → 时间。
        注意：**吊灯线用建仓以来的峰值**，峰值只由已发生的 K 线更新，
        因此本判定不含未来函数。
        """
        pnl = (close - pos.buy_price) / pos.buy_price
        max_pnl = pos.max_profit_pct

        # 1) 保本止损：浮盈足够时跌回成本+手续费
        be_trigger = float(self.params["breakeven_trigger_pct"])
        be_min = float(self.params["breakeven_min_profit_pct"])
        if max_pnl >= be_trigger and pnl <= be_min:
            return ExitKind.BREAKEVEN_STOP

        # 2) 硬止损
        if pnl <= -pos.hard_stop_mult * pos.atr_at_entry / pos.buy_price:
            return ExitKind.ATR_HARD_STOP

        # 3) 吊灯止盈
        if close <= pos.stop_price:
            return ExitKind.CHANDELIER_EXIT

        # 4) 档位止盈（浮盈分档回撤锁利）
        if self.params["profit_tier_enabled"]:
            if 0.05 <= max_pnl < 0.10 and max_pnl - pnl >= 0.03:
                return ExitKind.PROFIT_TIER
            if 0.10 <= max_pnl < 0.20 and max_pnl - pnl >= 0.08:
                return ExitKind.PROFIT_TIER
            if max_pnl >= 0.20 and max_pnl - pnl >= 0.15:
                return ExitKind.PROFIT_TIER

        # 5) 时间止损
        if pos.hold_days >= int(self.params["time_stop_days"]) and pnl <= 0:
            return ExitKind.TIME_STOP
        if pos.hold_days >= int(self.params["max_hold_days"]):
            return ExitKind.MAX_HOLD

        return None

    def _sell_price(self, pos: _OpenPosition, row: pd.Series, close: float) -> float:
        """卖出成交价

        若当日开盘已跌破止损位，按开盘价（更保守）；否则按收盘价。
        不使用当日最低价——那需要日内才能知道。
        """
        open_p = float(row["Open"])
        if open_p <= pos.stop_price:
            return open_p
        return close


__all__ = [
    "CostModel",
    "ExitKind",
    "Trade",
    "EquityPoint",
    "BacktestResult",
    "PortfolioBacktester",
    "DEFAULT_PORTFOLIO_PARAMS",
]