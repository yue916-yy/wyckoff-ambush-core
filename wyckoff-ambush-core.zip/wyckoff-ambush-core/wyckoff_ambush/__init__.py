"""
wyckoff-ambush-core
===================

威科夫 SOS 锚定 + VPA 量价情绪冰点潜伏策略核心库。

从 `lianghua` 项目剥离出的**纯策略内核**，不含数据获取、推送、订阅等工程层。

策略链条
--------
1. **SOS 锚定**  —— 识别需求大阳线（Sign of Strength），确认主力入场
2. **情绪冰点**  —— SOS 窗口期内等待 J 值超卖 + 缩量 + 小实体
3. **入场评分**  —— 4 维质量评分（J 值 / 量能 / 盘面 / 均线）+ 主力托底 4 因子
4. **退出体系**  —— 保本 / 硬止损 / 吊灯 / Buy Climax / 档位止盈 / 时间止损

版本演进
--------
| 版本 | 模块                | 核心贡献                             |
|------|---------------------|--------------------------------------|
| V6.0 | v60_ambush_model    | SOS 锚定 + 情绪冰点 5 条件信号       |
| V6.1 | v61_ambush_model    | ATR 动态止损 + Buy Climax 退出       |
| V6.2 | v62_ambush_model    | 行业动量过滤                         |
| V6.3 | v63_ambush_model    | 微观确认 + 波动率平价仓位 + 限价单   |
| V6.4 | v64_ambush_model    | 4 维入场质量评分 + 主力托底评分       |

重要说明
--------
**本库的信号检测逻辑（`Detect_AmbushSignal*`）经过验证，可直接使用。**

**但上游 `lianghua` 项目的回测业绩数字不可信**，原因见 `docs/UPSTREAM_AUDIT.md`：

- 原 `compute_metrics` 用 `sum(profit_pct)` 把每笔交易百分比直接相加，
  并把该和当作复利基数开 N 次方根，得出"年化收益"——这是双重虚构
- 原回测对每只股票独立分配 10 万初始资金，跨股票无组合资金约束
- 原 T+1 执行块存在日内前视偏差（用当日收盘 ATR 决定当日开盘仓位）

因此本库**不再提供回测收益结论**，改以 `backtest/portfolio.py` 提供
真实资金曲线的组合级回测，配合样本外切分使用。

许可证
------
MIT，见 LICENSE。原始作者 Lishoulan。
"""

__version__ = "1.0.0"
__original_project__ = "https://github.com/Lishoulan/lianghua"
__license__ = "MIT"

# 指标计算（所有模型的共同入口）
from .v60_ambush_model import (
    IndicatorCalcBase,
    Detect_AmbushSignal,
    DEFAULT_PARAMS,
)

# V6.1 风险控制
from .v61_ambush_model import (
    ExitReason,
    TradeRecord,
    Position,
    V61_PARAMS,
    Detect_AmbushSignal_V61,
    StatefulTradeBacktester_V61,
    compute_v61_metrics,
)

# V6.2 行业动量
from .v62_ambush_model import (
    compute_industry_momentum,
    build_industry_allow_matrix,
    V62_PARAMS,
)

# V6.3 微观确认 + 仓位 + 限价
from .v63_ambush_model import (
    add_micro_confirm_indicators,
    calc_volatility_parity_shares,
    calc_dynamic_stop_params,
    calc_limit_price,
    Detect_AmbushSignal_V63,
    V63_PARAMS,
)

# V6.4 入场质量评分（当前推荐使用的最新版本）
from .v64_ambush_model import (
    add_entry_quality_indicators,
    add_inst_support_indicators,
    Detect_AmbushSignal_V64,
    analyze_support_score_impact,
    V64_PARAMS,
)

# OAMV 市场择时
from .oamv_filter import OAMVHysteresisFilter

__all__ = [
    "__version__",
    "IndicatorCalcBase",
    "Detect_AmbushSignal",
    "DEFAULT_PARAMS",
    "ExitReason",
    "TradeRecord",
    "Position",
    "V61_PARAMS",
    "Detect_AmbushSignal_V61",
    "StatefulTradeBacktester_V61",
    "compute_v61_metrics",
    "compute_industry_momentum",
    "build_industry_allow_matrix",
    "V62_PARAMS",
    "add_micro_confirm_indicators",
    "calc_volatility_parity_shares",
    "calc_dynamic_stop_params",
    "calc_limit_price",
    "Detect_AmbushSignal_V63",
    "V63_PARAMS",
    "add_entry_quality_indicators",
    "add_inst_support_indicators",
    "Detect_AmbushSignal_V64",
    "analyze_support_score_impact",
    "V64_PARAMS",
    "OAMVHysteresisFilter",
]