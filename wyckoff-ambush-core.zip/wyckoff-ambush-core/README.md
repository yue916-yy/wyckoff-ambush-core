# wyckoff-ambush-core

**威科夫 SOS 锚定 + VPA 量价情绪冰点潜伏策略 —— 纯策略内核**

从 [`Lishoulan/lianghua`](https://github.com/Lishoulan/lianghua) 剥离的核心信号库。
不含数据获取、消息推送、订阅系统等工程层。

> **关于上游业绩数字**：原仓库 README 声称"5 年回测 +1389%、年化 63.4%"。
> 经代码审计，该数字由`百分比直接相加` + `对和再开方根`双重虚构得出，
> 且回测逐股独立分配 10 万资金、无组合约束。**请勿引用该数字做任何决策。**
> 详细复算见 [`docs/UPSTREAM_AUDIT.md`](docs/UPSTREAM_AUDIT.md)。

---

## 策略逻辑

```
┌─ L1 信号检测 ─────────────────────────────────────────┐
│  ① SOS 锚定        需求大阳线，确认主力已入场           │
│  ② 情绪冰点        J值超卖 + 缩量 + 小实体               │
│  ③ 支撑有效        收盘不低于均线托底位                  │
│  → ④ T+1 开盘执行（含防高开 / 防破位）                  │
└────────────────────────────────────────────────────────┘
┌─ L2 入场评分（0-8 分）───────────────────────────────┐
│  J值深度 / 量能枯竭 / 盘面形态 / 均线结构              │
│  + 主力托底 4 因子（缩量企稳 / 量价底背离 /            │
│                  支撑反复试探 / 日内承接）              │
└────────────────────────────────────────────────────────┘
┌─ L3 退出体系（按优先级）───────────────────────────────┐
│  保本 → 硬止损(ATR) → 吊灯止盈 → 档位止盈 → 时间止损  │
└────────────────────────────────────────────────────────┘
```

信号判定的核心不变量（已由测试保证）：

```python
ambush_signal = sos_in_window & j_oversold & vol_shrink & tiny_body & support_ok
#                  ↑ 窗口内有SOS     ↑ 超卖    ↑ 抛压枯竭  ↑ 砸不动   ↑ 均线托底
```

---

## 安装

```bash
pip install wyckoff-ambush-core
```

或从源码：

```bash
git clone https://github.com/yue916-yy/wyckoff-ambush-core.git
cd wyckoff-ambush-core
pip install -e ".[dev]"
```

依赖：Python ≥ 3.10、pandas、numpy。**无数据源依赖、无推送依赖。**

---

## 快速开始

```python
import pandas as pd
from wyckoff_ambush import (
    IndicatorCalcBase,
    add_micro_confirm_indicators,
    add_entry_quality_indicators,
    add_inst_support_indicators,
    Detect_AmbushSignal_V64,
    V64_PARAMS,
)

# df 需含 Open/High/Low/Close/Volume，DatetimeIndex
df = IndicatorCalcBase(df)                          # 1. 指标
df = add_micro_confirm_indicators(df)               # 2. 微观确认
df = add_entry_quality_indicators(df, V64_PARAMS)   # 3. 入场质量评分
df = add_inst_support_indicators(df, V64_PARAMS)    # 4. 主力托底评分
df = Detect_AmbushSignal_V64(df, V64_PARAMS)        # 5. 信号判定

signals = df[df["ambush_signal"] & (df["entry_quality_score"] >= 4)]
print(signals[["Close", "J", "entry_quality_score", "inst_support_score"]])
```

### 组合级回测

```python
from wyckoff_ambush.backtest import PortfolioBacktester, CostModel

# prepared: {ts_code: 已计算指标的 DataFrame}
bt = PortfolioBacktester(params={
    "initial_cash": 100_000,
    "max_concurrent_positions": 5,
    "max_position_pct": 0.20,
    "entry_quality_min_score": 4,
    "cost_model": CostModel(),
})

result = bt.run(prepared, start="2021-01-01", end="2026-12-31")
print(result.summary())
```

输出示例（`examples/quickstart.py` 在合成数据 + 注入确定性信号下的真实输出）：

```
──────────────────────────────────────────────────────────────
  组合级回测结果（真实资金曲线）
──────────────────────────────────────────────────────────────
  期初权益            100,000.00
  期末权益             79,308.87
  累计收益率              -20.69%
  年化收益率              -12.67%
  最大回撤                -20.92%
  夏普比率                 -6.64
──────────────────────────────────────────────────────────────
  交易笔数                    65
  胜率                       4.62%
  盈亏比                      0.00
  平均持仓                    8.75 天
──────────────────────────────────────────────────────────────
  总盈亏金额          -20,752.76
  总交易费用            1,384.36
──────────────────────────────────────────────────────────────
  退出分布:
    时间止损            44 笔
    硬止损             14 笔
    信号结束             4 笔
    吊灯止盈             3 笔
──────────────────────────────────────────────────────────────
```

> ⚠️ 上述为**合成数据 + 注入确定性信号**的输出，**无金融含义**，
> 仅用于演示引擎的计算路径（含成本扣除、退出判定、回撤计算）。

### ⚠️ 关于信号稀疏性

SOS 锚定需 **11 重条件同时成立**（趋势环境 + 左侧枯竭 + 阳线 + 实体饱满
+ 收偏上 + 放量突破 + 支撑有效 + 不过度 + 股性活跃 + 龙回头），
在缺乏真实量价结构的数据上**极少触发**——实测即使构造教科书形态的
合成行情也难以稳定产生信号。

这是策略的**特性而非缺陷**：严格的多重过滤换来信号质量。
接入真实 A 股行情后信号频率会显著高于合成数据。

---

## 为什么用 `PortfolioBacktester` 而不直接跑上游回测

| 维度 | 上游 `StatefulTradeBacktester_V64` | 本库 `PortfolioBacktester` |
|------|--------------------------------------|--------------------------|
| 资金池 | 每只股票独立 10 万 | 全部股票共享一个 cash |
| 同时持仓 | 无约束 | `max_concurrent_positions` |
| 仓位基准 | `initial_cash`（恒定） | 当前总权益（真实复利） |
| 累计收益 | `sum(profit_pct)` ← **双重虚构** | 期末权益 / 期初权益 − 1 |
| 年化 | 对百分比和开方根 | 资金曲线几何年化 |
| 交易成本 | 无 | 双边佣金 + 印花税 + 过户费 |
| T+1 成交 | 用当日最低价（**前视**） | 只用开盘价 |
| 吊灯线 | 同根K线先取最高再判收盘（**前视**） | 峰值只由已发生 K 线更新 |

---

## 版本演进

| 版本 | 模块 | 核心贡献 |
|------|------|---------|
| V6.0 | `v60_ambush_model` | SOS 锚定 + 5 条件情绪冰点信号 |
| V6.1 | `v61_ambush_model` | ATR 动态止损 + Buy Climax 退出 |
| V6.2 | `v62_ambush_model` | 行业动量过滤 |
| V6.3 | `v63_ambush_model` | 微观确认 + 波动率平价仓位 + 限价单 |
| **V6.4** | `v64_ambush_model` | **4 维入场评分 + 主力托底评分（推荐）** |
| — | `oamv_filter` | OAMV 市场择时状态机 |

---

## 市场择时（可选）

```python
from wyckoff_ambush import OAMVHysteresisFilter

# amv_df 需含 amount 或 close*volume 的日度序列
f = OAMVHysteresisFilter(
    upper_threshold=2.0, lower_threshold=-1.0,
    smooth_method="sma", smooth_period=15,
    cost_ma_method="sma", cost_ma_period=42,
)
f.fit(amv_df)
state = f.get_state_df()          # oamv_state: 1=牛 0=熊
allowed = f.is_trading_allowed()  # 日线 + 周线双重确认
```

> 注意：上游阈值是在**全样本**上网格搜索得出的（无样本外切分），
> 默认参数 `+2.0% / −1.0%` 存在过拟合风险，建议自行做样本外验证。

---

## 测试

```bash
pip install -e ".[dev]"
pytest tests/ -v
```

测试覆盖：
- 指标计算的值域、不变性、零波动边界
- **信号不变量**：有信号必有窗口内 SOS 锚定、必有 J 值超卖
- 评分一致性：总分 = 四子分之和、子分值域 0-2
- **回测口径回归**：总收益 = 期末/期初 − 1，且小于百分比之和
- **无前视检验**：篡改未来数据后，历史交易必须完全不变
- 资金约束：现金不为负、整手交易、持仓数不超限

---

## 开发

```bash
pytest tests/ -v
ruff check wyckoff_ambush/ tests/
```

## 许可证

MIT。原始作者 [Lishoulan](https://github.com/Lishoulan/lianghua)。
本仓库为策略内核的重新发布，保留原版权声明，详见 [LICENSE](LICENSE)。

## 免责声明

本项目仅供学习和研究使用，**不构成任何投资建议**。量化交易存在风险，使用者需自行承担一切后果。
回测基于历史数据，不代表未来收益。