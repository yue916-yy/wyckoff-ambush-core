"""
最小可用示例：合成数据 → 信号检测 → 组合回测
=============================================

本示例**不需要真实数据或 API Key**，用合成行情完整演示本库的工作流。
可直接运行：

    python examples/quickstart.py

要接入真实数据，请替换 `build_universe()`，
然后沿用后面的流程不变。

重要：本示例的回测输出基于**随机生成的合成数据**，
其收益数字没有任何金融含义，仅用于演示 API 怎么用。
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from wyckoff_ambush import (
    IndicatorCalcBase,
    add_micro_confirm_indicators,
    add_entry_quality_indicators,
    add_inst_support_indicators,
    Detect_AmbushSignal_V64,
    V64_PARAMS,
)
from wyckoff_ambush.backtest import CostModel, PortfolioBacktester


def build_universe(n_codes: int = 40, n_days: int = 500, seed: int = 2024):
    """构造合成股票池

    **不是纯随机游走**——纯随机数据几乎触发不了 SOS 的 11 重条件，
    信号数会恒为 0，示例就失去演示价值。

    这里按威科夫教科书形态注入信号机会：
      阶段 A（平缓缩量阴跌）→ 阶段 T（末端极度缩量枯竭）
      → 阶段 B（SOS 涨停突破）→ 阶段 C（缩量小实体冰点）

    再叠加个股差异化的漂移与波动率，使各股表现不同。
    这些形态参数是**为了让演示流程可跑通**，不是策略参数。
    """
    rng = np.random.default_rng(seed)
    universe = {}
    a_days, tail_days, b_days, c_days = 45, 3, 2, 14
    cycle = a_days + tail_days + b_days + c_days
    n_cycles = n_days // cycle

    for i in range(n_codes):
        rows = []
        price = 40.0 * float(rng.uniform(0.6, 1.6))     # 个股价格差异
        drift = rng.normal(0.0004, 0.0003)               # 个股漂移
        vol = rng.uniform(0.014, 0.026)                  # 个股波动

        for _ in range(n_cycles):
            # A: 平缓缩量阴跌
            for _ in range(a_days):
                price *= 1 + drift - abs(rng.normal(0.004, vol * 0.3))
                rows.append((price, float(rng.integers(18_000, 35_000)),
                             float(rng.uniform(0.004, 0.009))))

            # T: 末端极度缩量枯竭（No Supply）
            pv = rows[-1][1]
            for _ in range(tail_days):
                price *= 1 + drift * 0.3 - abs(rng.normal(0.001, vol * 0.1))
                pv *= 0.75
                rows.append((price, float(pv), float(rng.uniform(0.001, 0.003))))

            # B: SOS 涨停光头阳线
            for _ in range(b_days):
                price *= 1 + abs(rng.normal(0.098, 0.004))
                rows.append((price, float(rng.integers(400_000, 700_000)), 0.0015))

            # C: 缩量小实体冰点
            for _ in range(c_days):
                price *= 1 + drift - abs(rng.normal(0.003, vol * 0.1))
                rows.append((price, float(rng.integers(15_000, 30_000)),
                             float(rng.uniform(0.002, 0.005))))

        idx = pd.bdate_range(start="2021-01-04", periods=len(rows))
        df = pd.DataFrame(
            {"Close": [r[0] for r in rows],
             "Volume": [r[1] for r in rows],
             "VRatio": [r[2] for r in rows]},
            index=idx,
        )
        df["Open"] = df["Close"] * (1 - df["VRatio"])
        df["High"] = np.maximum(df["Open"], df["Close"]) * (1 + df["VRatio"] * 0.15)
        df["Low"] = np.minimum(df["Open"], df["Close"]) * (1 - df["VRatio"] * 0.15)
        universe[f"{600000 + i:06d}.SH"] = df[["Open", "High", "Low", "Close", "Volume"]]

    return universe


def prepare(df: pd.DataFrame) -> pd.DataFrame:
    """把原始 OHLCV 走完完整信号流水线"""
    out = IndicatorCalcBase(df)
    out = add_micro_confirm_indicators(out)
    out = add_entry_quality_indicators(out, V64_PARAMS)
    out = add_inst_support_indicators(out, V64_PARAMS)
    out = Detect_AmbushSignal_V64(out, V64_PARAMS)
    return out


def main():
    print("=" * 70)
    print("  wyckoff-ambush-core 快速示例")
    print("=" * 70)

    # ── 1. 构造数据 ────────────────────────────────────────────
    print("\n[1/4] 构造合成股票池 ...")
    universe = build_universe(n_codes=40, n_days=500)
    print(f"      {len(universe)} 只股票 × {len(next(iter(universe.values())))} 个交易日")

    # ── 2. 信号计算 ────────────────────────────────────────────
    print("\n[2/4] 计算指标与信号 ...")
    prepared = {code: prepare(df) for code, df in universe.items()}

    total_signals = sum(int(df["ambush_signal"].sum()) for df in prepared.values())
    gated = sum(
        int((df["ambush_signal"] & (df["entry_quality_score"] >= 4)).sum())
        for df in prepared.values()
    )
    print(f"      原始信号数:{total_signals}")
    print(f"      评分≥4 过滤后:      {gated}")

    if total_signals == 0:
        print(
            "\n      ⚠️形态化合成数据下未触发信号。\n"
            "         这是策略的真实特性：SOS 锚定需 11 重条件同时成立\n"
            "         （趋势 + 左侧枯竭 + 放量突破 + 股性活跃 + 支撑 ...），\n"
            "         在缺乏真实量价结构的数据上极少满足。\n"
            "         下面改用确定性注入信号，演示回测引擎的工作方式。"
        )

    # ── 3. 抽样查看指标与评分 ──────────────────────────────────
    print("\n[3/4] 抽样查看指标输出（示例个股）...")
    sample_code = next(iter(prepared))
    sample = prepared[sample_code].tail(5)
    cols = ["Close", "J", "atr14", "entry_quality_score", "inst_support_score"]
    cols = [c for c in cols if c in sample.columns]
    print(f"      {sample_code} 最近 5 日：")
    print(sample[cols].to_string())

    # ── 4. 回测引擎演示 ────────────────────────────────────────
    print("\n[4/4] 回测引擎演示 ...")
    # 若真实信号为空，注入确定性信号以展示引擎行为
    if total_signals == 0:
        demo = inject_demo_signals(prepared)
        print("      （已注入确定性信号以演示引擎，下方数字非策略业绩）")
    else:
        demo = prepared

    bt = PortfolioBacktester(
        params={
            "initial_cash": 100_000.0,
            "max_concurrent_positions": 5,
            "max_position_pct": 0.20,
            "entry_quality_min_score": 4,
            "cost_model": CostModel(),
        }
    )
    result = bt.run(demo, start="2021-01-04", end="2023-12-29")

    print()
    print(result.summary())

    # ── 5. 样本外切分演示 ──────────────────────────────────────
    print("\n[附加] 样本外切分演示（训练期与测试期分开评估）")
    print("-" * 70)
    for label, (start, end) in [
        ("训练期 2021-01 ~ 2022-12", ("2021-01-04", "2022-12-30")),
        ("测试期 2023-01 ~ 2023-12", ("2023-01-02", "2023-12-29")),
    ]:
        r = bt.run(demo, start=start, end=end)
        print(
            f"  {label}: "
            f"收益 {r.total_return_pct:>8.2f}%  "
            f"回撤 {r.max_drawdown_pct:>7.2f}%  "
            f"夏普 {r.sharpe:>6.2f}  "
            f"交易 {r.total_trades:>3d} 笔  "
            f"胜率 {r.win_rate:>5.1f}%"
        )

    print("\n" + "=" * 70)
    print("  注意：以上数字基于合成数据，无金融含义。")
    print("  真实评估请接入真实行情，并务必做样本外切分。")
    print("=" * 70)


def inject_demo_signals(prepared):
    """注入确定性信号，仅用于演示回测引擎

    在 SOS 条件极严的合成数据上，用固定周期信号让引擎跑起来，
    展示资金曲线、退出分布、成本扣除等计算是否正确。
    """
    out = {}
    for i, (code, df) in enumerate(prepared.items()):
        d = df.copy()
        n = len(d)
        # 每 25 天一个信号，个股错开起始位置
        sig = np.zeros(n, dtype=bool)
        offset = (i * 5) % 25
        sig[offset::25] = True
        # 保证触发买入的前置条件满足：ATR>0、不高开、不破位
        d["atr14"] = np.where(d["atr14"] <= 0, 0.01, d["atr14"])
        d["ambush_signal"] = sig
        d["entry_quality_score"] = 6
        out[code] = d
    return out


if __name__ == "__main__":
    main()