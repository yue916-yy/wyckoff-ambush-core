"""信号检测逻辑测试

验证从 lianghua 提取的信号引擎在剥离后行为一致且正确。
"""
import numpy as np
import pandas as pd
import pytest

from wyckoff_ambush import (
    IndicatorCalcBase,
    Detect_AmbushSignal,
    DEFAULT_PARAMS,
    Detect_AmbushSignal_V64,
    add_micro_confirm_indicators,
    add_entry_quality_indicators,
    add_inst_support_indicators,
    V64_PARAMS,
)


def make_bars(n=200, seed=42, start="2021-01-01"):
    """构造合成 OHLCV：随机游走 + 偶发大阳线"""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, periods=n)
    close = 10 + np.cumsum(rng.normal(0, 0.25, n))
    close = np.maximum(close, 1.0)
    open_ = close * (1 + rng.normal(0, 0.006, n))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.008, n)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.008, n)))
    volume = rng.integers(50_000, 500_000, n).astype(float)
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low,
         "Close": close, "Volume": volume},
        index=dates,
    )


def with_base(n=300, seed=42):
    """IndicatorCalcBase 之后的 DataFrame

    add_entry_quality_indicators / add_inst_support_indicators 依赖
    volume_ma、atr14、yellow_line 等前置列，必须先过指标层。
    """
    return IndicatorCalcBase(make_bars(n=n, seed=seed))


def make_sos_bars(cycles=5, a_days=45, tail_days=3, b_days=2, c_days=14):
    """构造能触发完整 SOS + 情绪冰点链的形态化数据

    纯随机游走几乎不产生信号（SOS 需 11 重条件同时成立），
    因此这里按威科夫教科书形态 + A 股实际涨跌停幅度显式构造：

      阶段 A（缩量阴跌）→ 阶段 T（末端极度缩量枯竭）→ 阶段 B（SOS 涨停）→ 阶段 C（缩量小实体冰点）

    **阶段 T 是必需的**，这是实测得出的关键约束：

    SOS 要求 `②左侧枯竭（近3日 No Supply 或 Test）` 与 `⑥放量突破` 同时成立。
    若阶段 A 全程都是持续放量下跌，枯竭窗口与量能爆发窗口**不重叠**，
    `tag_sos` 恒为 0。威科夫原意正是"抛压耗尽后才放量拉起"，
    因此需要在阴跌末端插入极度缩量的枯竭段。

    其他构造要点（均经调试验证，缺一不可）：

    1. **实体占比 > 50%**（`sos_body_ratio`）：SOS 日用光头光脚涨停阳线
    2. **趋势成立**（`white_line > yellow_line`）：阴跌须平缓，急跌会拉成空头排列
    3. **股性活跃**：20 日内需日涨幅 > 9.5% 或振幅 > 10%
    4. **龙回头**：30 日内最高涨幅 > ATR 均值 × 200，靠涨停幅度满足
    """
    rng = np.random.default_rng(11)
    rows = []
    price = 40.0

    for _ in range(cycles):
        # ── A: 平缓缩量阴跌（不可急跌，否则趋势条件不成立）
        for _ in range(a_days):
            price *= 1 - abs(rng.normal(0.004, 0.0015))
            rows.append((
                price,
                float(rng.integers(18_000, 35_000)),
                float(rng.uniform(0.004, 0.009)),
            ))

        # ── T: 末端极度缩量枯竭（No Supply 条件）
        # 价微幅波动 + 量能持续递减 + 振幅收敛
        prev_v = rows[-1][1]
        for _ in range(tail_days):
            price *= 1 - abs(rng.normal(0.001, 0.0005))
            prev_v *= 0.75                                  # 量能递减 → 满足 No Supply
            rows.append((
                price,
                float(prev_v),
                float(rng.uniform(0.001, 0.003)),
            ))

        # ── B: SOS 涨停光头阳线（放量突破昨日高点）
        for _ in range(b_days):
            price *= 1 + abs(rng.normal(0.098, 0.004))
            rows.append((
                price,
                float(rng.integers(400_000, 700_000)),
                0.0015,                                      # 极短影线 → 实体占比 > 99%
            ))

        # ── C: 缩量小实体冰点（J 值回落至超卖区）
        for _ in range(c_days):
            price *= 1 - abs(rng.normal(0.003, 0.0015))
            rows.append((
                price,
                float(rng.integers(15_000, 30_000)),
                float(rng.uniform(0.002, 0.005)),           # 小实体 < 3%
            ))

    idx = pd.bdate_range(start="2021-01-04", periods=len(rows))
    df = pd.DataFrame(
        {
            "Close": [r[0] for r in rows],
            "Volume": [r[1] for r in rows],
            "VRatio": [r[2] for r in rows],
        },
        index=idx,
    )
    df["Open"] = df["Close"] * (1 - df["VRatio"])
    df["High"] = np.maximum(df["Open"], df["Close"]) * (1 + df["VRatio"] * 0.15)
    df["Low"] = np.minimum(df["Open"], df["Close"]) * (1 - df["VRatio"] * 0.15)
    return df[["Open", "High", "Low", "Close", "Volume"]]


class TestIndicatorCalcBase:
    def test_produces_expected_columns(self):
        df = make_bars()
        out = IndicatorCalcBase(df)
        for col in ["white_line", "yellow_line", "ma14", "ma28",
                    "ma57", "ma114", "atr14", "volume_ma", "K", "D", "J"]:
            assert col in out.columns, f"缺列: {col}"

    def test_j_within_clip_range(self):
        df = IndicatorCalcBase(make_bars())
        assert df["J"].min() >= 0.0
        assert df["J"].max() <= 100.0

    def test_atr_positive(self):
        df = IndicatorCalcBase(make_bars())
        assert (df["atr14"] > 0).all()

    def test_zero_volatility_series_does_not_crash(self):
        dates = pd.bdate_range("2021-01-01", periods=120)
        n = len(dates)
        df = pd.DataFrame({
            "Open": [10.0]*n, "High": [10.0]*n, "Low": [10.0]*n,
            "Close": [10.0]*n, "Volume": [1000.0]*n,
        }, index=dates)
        out = IndicatorCalcBase(df)          # 不应抛异常
        assert len(out) == n

    def test_does_not_mutate_input(self):
        df = make_bars()
        before = df.copy()
        IndicatorCalcBase(df)
        pd.testing.assert_frame_equal(df, before)


class TestDetectAmbushSignal:
    def test_emits_all_signal_columns(self):
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars()), DEFAULT_PARAMS)
        for col in ["tag_sos_anchor", "tag_no_supply", "tag_test",
                    "ambush_signal", "near_signal_count"]:
            assert col in df.columns

    def test_signal_is_bool_dtype(self):
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars()), DEFAULT_PARAMS)
        assert df["ambush_signal"].dtype == bool

    def test_near_signal_count_range(self):
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars()), DEFAULT_PARAMS)
        assert df["near_signal_count"].between(0, 5).all()

    def test_signal_implies_sos_anchor_in_window(self):
        """核心不变量：潜伏信号必须在前置窗口内存在 SOS 锚定

        这是策略逻辑的根基——没有 SOS 就不该有"潜伏"。
        """
        params = {**DEFAULT_PARAMS, "ambush_window": 10}
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars(n=400)), params)
        window = params["ambush_window"]
        for i in np.flatnonzero(df["ambush_signal"].values):
            lo = max(0, i - window + 1)
            segment = df["tag_sos_anchor"].values[lo:i + 1]
            assert segment.any(), f"第 {i} 行有信号但窗口内无 SOS 锚定"

    def test_signal_implies_oversold_and_support(self):
        """信号必须同时满足 J值超卖 与 收盘不低于均线托底

        注意：SOS 的 11 重条件在单边下跌行情中极难全部成立（本库实测
        纯形态化合成数据也难以稳定触发），因此**不强制要求信号非空**，
        只验证"一旦有信号就必须满足不变量"。这既保证测试稳定，
        也如实反映了策略信号稀疏这一事实。
        """
        params = {**DEFAULT_PARAMS}
        df = Detect_AmbushSignal(
            IndicatorCalcBase(make_sos_bars()), params
        )
        sig = df[df["ambush_signal"]]
        if len(sig) == 0:
            pytest.skip("该形态下未产生信号，条件为 vacuously true")
        assert (sig["J"] < params["ambush_j_oversold"]).all()
        tol = params["ambush_support_atr"] * sig["atr14"]
        assert (sig["Close"] >= sig["yellow_line"] - tol - 1e-9).all()

    def test_signal_is_sparse_on_synthetic_data(self):
        """记录信号稀疏性：5 条件 AND 使信号天然稀少

        这是策略特性而非缺陷——严格的多重过滤换来的是信号质量。
        测试目的是把这个事实固化下来，避免日后误改导致信号泛滥。
        """
        params = {**DEFAULT_PARAMS}
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars(n=1000)), params)
        ratio = df["ambush_signal"].sum() / len(df)
        assert ratio < 0.15, f"信号率 {ratio:.2%} 偏高，疑似过滤条件失效"

    def test_signal_implies_oversold_on_random_walk(self):
        """随机游走数据下信号可能极少甚至为无——但一旦有就必须满足不变量

        记录这一事实：5 条件 AND 非常严格，实盘信号稀疏是预期行为。
        """
        params = {**DEFAULT_PARAMS}
        df = Detect_AmbushSignal(IndicatorCalcBase(make_bars(n=800)), params)
        sig = df[df["ambush_signal"]]
        # 不要求非空，只要求满足不变量
        if len(sig):
            assert (sig["J"] < params["ambush_j_oversold"]).all()

    def test_no_future_leakage_sos_anchor(self):
        """SOS 锚定不得使用当日量能之外的未来信息

        改写最后一个 bar 的数据后，之前所有行的信号不应改变。
        """
        df = make_bars(n=300)
        base = Detect_AmbushSignal(IndicatorCalcBase(df), DEFAULT_PARAMS)
        df2 = df.copy()
        df2.iloc[-1, df2.columns.get_loc("Volume")] *= 50
        alt = Detect_AmbushSignal(IndicatorCalcBase(df2), DEFAULT_PARAMS)
        # 最后一行允许变化，但前 n-1 行必须完全一致
        pd.testing.assert_series_equal(
            base["tag_sos_anchor"].iloc[:-1],
            alt["tag_sos_anchor"].iloc[:-1],
        )


class TestEntryQualityScore:
    def test_score_equals_sum_of_subscores(self):
        """入场总分必须等于四个子维度之和"""
        df = add_entry_quality_indicators(with_base(300), V64_PARAMS)
        subs = ["eq_j_score", "eq_vol_score", "eq_candle_score", "eq_ma_score"]
        for c in subs:
            assert c in df.columns, f"缺子维度列: {c}"
        total = df[subs].sum(axis=1)
        assert (df["entry_quality_score"] == total).all()

    def test_score_within_0_to_8(self):
        df = add_entry_quality_indicators(with_base(300), V64_PARAMS)
        assert df["entry_quality_score"].between(0, 8).all()

    def test_subscores_within_0_to_2(self):
        df = add_entry_quality_indicators(with_base(300), V64_PARAMS)
        for c in ["eq_j_score", "eq_vol_score", "eq_candle_score", "eq_ma_score"]:
            assert df[c].between(0, 2).all(), f"{c} 越界"


class TestInstSupport:
    def test_emits_factor_columns(self):
        df = add_inst_support_indicators(with_base(300), V64_PARAMS)
        for c in ["factor_a_vol_stable", "factor_b_vp_divergence",
                  "factor_c_support_hold", "factor_d_intraday_accum"]:
            assert c in df.columns

    def test_support_score_within_0_to_4(self):
        df = add_inst_support_indicators(with_base(300), V64_PARAMS)
        assert df["inst_support_score"].between(0, 4).all()


class TestV64Pipeline:
    def test_full_pipeline_runs(self):
        """完整流水线：指标 → 微观确认 → 评分 → 信号"""
        df = make_bars(n=300)
        df = IndicatorCalcBase(df)
        df = add_micro_confirm_indicators(df)
        df = add_entry_quality_indicators(df, V64_PARAMS)
        df = add_inst_support_indicators(df, V64_PARAMS)
        df = Detect_AmbushSignal_V64(df, V64_PARAMS)
        assert "ambush_signal" in df.columns
        assert df["entry_quality_score"].between(0, 8).all()

    def test_high_score_gate_filters_signals(self):
        """提高评分门槛后，信号数量不应增加"""
        df = make_bars(n=500)
        df = IndicatorCalcBase(df)
        df = add_micro_confirm_indicators(df)
        df = add_entry_quality_indicators(df, V64_PARAMS)
        df = add_inst_support_indicators(df, V64_PARAMS)
        df = Detect_AmbushSignal_V64(df, V64_PARAMS)

        raw = df["ambush_signal"].sum()
        gated = (
            df["ambush_signal"] & (df["entry_quality_score"] >= 6)
        ).sum()
        assert gated <= raw