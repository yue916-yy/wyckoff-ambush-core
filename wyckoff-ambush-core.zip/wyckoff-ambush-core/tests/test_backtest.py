"""组合级回测器测试

重点验证上游三个核心缺陷已被修正：
1. 收益基于真实资金曲线，而非百分比相加
2. 组合级资金约束生效
3. 交易成本被扣除
"""
import numpy as np
import pandas as pd
import pytest

from wyckoff_ambush.backtest import (
    PortfolioBacktester,
    CostModel,
    ExitKind,
    DEFAULT_PORTFOLIO_PARAMS,
)


def make_bars(n=300, seed=7, start="2021-01-01", drift=0.0008):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, periods=n)
    ret = rng.normal(drift, 0.02, n)
    close = 10 * np.exp(np.cumsum(ret))
    open_ = close * (1 + rng.normal(0, 0.005, n))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.007, n)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.007, n)))
    volume = rng.integers(80_000, 400_000, n).astype(float)
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low,
         "Close": close, "Volume": volume},
        index=dates,
    )


def make_universe(n_codes=40, n=400, seed=11):
    return {
        f"{600000 + i:06d}.SH": make_bars(n, seed=seed + i)
        for i in range(n_codes)
    }


def add_signal_col(frames, score=6):
    """给 DataFrame 注入满足门槛的信号列"""
    out = {}
    for code, df in frames.items():
        d = df.copy()
        n = len(d)
        d["atr14"] = (d["High"] - d["Low"]).rolling(14).mean().fillna(0.5)
        # 每 20 天制造一个信号
        sig = np.zeros(n, dtype=bool)
        sig[::20] = True
        d["ambush_signal"] = sig
        d["entry_quality_score"] = score
        out[code] = d
    return out


class TestCostModel:
    def test_buy_cost_positive(self):
        c = CostModel()
        assert c.buy_cost(100_000) > 0

    def test_sell_cost_higher_than_buy(self):
        """卖出含印花税，应略高于买入"""
        c = CostModel()
        assert c.sell_cost(100_000) > c.buy_cost(100_000)

    def test_min_commission_floor(self):
        """小额交易应触发最低佣金"""
        c = CostModel()
        # 1000 元按万2.5 = 0.25 元，低于 5 元下限
        assert c.buy_cost(1000) >= 5.0


class TestEquityCurveMetrics:
    def test_total_return_uses_real_equity(self):
        """核心回归测试：总收益必须等于 期末/期初 - 1"""
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        expected = (res.final_equity / res.initial_cash - 1) * 100
        assert res.total_return_pct == pytest.approx(expected)

    def test_not_equal_to_sum_of_percentages(self):
        """防止回归到上游的 sum(profit_pct) 口径

        上游把 869 笔各 1.6% 相加得 1390%。本实现必须给出
        远小于该和的数字（因为有资金约束和仓位限制）。
        """
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        naive_sum = sum(t.net_return_pct for t in res.trades)
        # 真实收益必然 ≤ 每笔收益率之和（仓位<100%）
        assert res.total_return_pct < naive_sum

    def test_annualized_uses_real_calendar(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        days = (res.equity_curve[-1].date - res.equity_curve[0].date).days
        years = days / 365.25
        expected = (
            (res.final_equity / res.initial_cash) ** (1 / years) - 1
        ) * 100
        assert res.annualized_return_pct == pytest.approx(expected, rel=1e-6)

    def test_drawdown_non_positive(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        assert res.max_drawdown_pct <= 0.0

    def test_max_drawdown_is_negative_when_loss(self):
        """回归测试：亏损回测的最大回撤必须是负值

        曾出现过 `max()` / `min()` 用反导致回撤恒为 0 的缺陷——
        drawdown 记为负值，必须取最小值。
        """
        frames = add_signal_col(make_universe(20, 300))
        # 人为制造下跌：连续大跌
        for df in frames.values():
            df.iloc[:, df.columns.get_loc("Close")] = np.linspace(
                20.0, 5.0, len(df)
            )
            df.iloc[:, df.columns.get_loc("Open")] = df["Close"] * 1.001
            df.iloc[:, df.columns.get_loc("High")] = df["Close"] * 1.01
            df.iloc[:, df.columns.get_loc("Low")] = df["Close"] * 0.99

        res = PortfolioBacktester().run(frames)
        if res.max_drawdown_pct == 0.0 and res.total_return_pct < -1.0:
            pytest.fail("亏损超过 1% 但最大回撤为 0，max_drawdown 计算有误")

    def test_equity_curve_has_no_artificial_drops(self):
        """回归测试：权益曲线不应出现现金同步缺失造成的断层

        曾出现卖出时 cash 增加但 equity 未同步，导致单日暴跌数十个百分点的缺陷。
        这里检查：单日权益跌幅不应超过可解释范围（持仓浮亏上限）。
        """
        frames = add_signal_col(make_universe(20, 300))
        res = PortfolioBacktester().run(frames)
        eq = [p.equity for p in res.equity_curve]
        for prev, cur in zip(eq, eq[1:]):
            if prev > 0:
                drop = (prev - cur) / prev * 100
                # 单日跌幅超过 50% 必然是计算缺陷（A股日内跌幅上限 20%）
                assert drop < 50.0, f"单日权益跌幅 {drop:.1f}% 异常"

    def test_win_rate_range(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        assert 0.0 <= res.win_rate <= 100.0


class TestPortfolioConstraints:
    def test_cash_never_negative(self):
        """资金池不允许透支"""
        bt = PortfolioBacktester(params={"max_concurrent_positions": 8})
        res = bt.run(add_signal_col(make_universe(30, 300)))
        assert all(p.cash >= -1e-6 for p in res.equity_curve)

    def test_max_concurrent_positions_respected(self):
        """同时持仓数不得超过上限"""
        max_pos = 3
        bt = PortfolioBacktester(
            params={"max_concurrent_positions": max_pos,
                    "max_position_pct": 0.30}
        )
        res = bt.run(add_signal_col(make_universe(30, 400)))
        # 从权益曲线反推：持仓市值 / 权益 不应超过 max_pos * max_pct
        for p in res.equity_curve:
            if p.equity > 0:
                assert p.position_value <= max_pos * 0.30 * p.equity + 1.0

    def test_no_exceeds_cash_at_entry(self):
        """单笔买入金额不超过可用现金"""
        bt = PortfolioBacktester(params={"max_position_pct": 0.25})
        res = bt.run(add_signal_col(make_universe(25, 300)))
        for t in res.trades:
            assert t.cost_basis > 0

    def test_shares_are_round_lots(self):
        """A 股必须整手（100 股倍数）"""
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        for t in res.trades:
            assert t.shares % 100 == 0, f"非整手: {t.shares}"


class TestNoLookahead:
    def test_buy_uses_open_price_only(self):
        """成交价必须等于买入日开盘价（不看收盘/最低）"""
        bt = PortfolioBacktester()
        frames = add_signal_col(make_universe(20, 300))
        res = bt.run(frames)
        for t in res.trades[:50]:
            bar = frames[t.ts_code].loc[t.buy_date]
            # buy_price 按 3 位小数记录，故用 abs=1e-3 容差
            assert t.buy_price == pytest.approx(float(bar["Open"]), abs=1e-3)

    def test_future_data_does_not_change_past_trades(self):
        """核心无前视检验：改动最后一段数据，不应影响之前的交易"""
        frames = add_signal_col(make_universe(20, 300))
        bt = PortfolioBacktester()
        res_a = bt.run(frames, end=str(frames[list(frames)[0]].index[200].date()))

        frames2 = add_signal_col(make_universe(20, 300))
        # 篡改最后 30 天的价格
        for code, df in frames2.items():
            df.iloc[-30:, df.columns.get_loc("Close")] *= 3.0
            df.iloc[-30:, df.columns.get_loc("High")] *= 3.0
        res_b = bt.run(frames2, end=str(frames[list(frames)[0]].index[200].date()))

        assert len(res_a.trades) == len(res_b.trades)
        for ta, tb in zip(res_a.trades, res_b.trades):
            assert ta.ts_code == tb.ts_code
            assert ta.buy_date == tb.buy_date
            assert ta.sell_date == tb.sell_date
            assert ta.buy_price == pytest.approx(tb.buy_price)


class TestExitMechanics:
    def test_all_trades_have_valid_exit_reason(self):
        bt = PortfolioBacktestter = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        for t in res.trades:
            assert isinstance(t.exit_reason, ExitKind)

    def test_hold_days_within_limit(self):
        bt = PortfolioBacktester()
        max_hold = int(DEFAULT_PORTFOLIO_PARAMS["max_hold_days"])
        res = bt.run(add_signal_col(make_universe(20, 400)))
        for t in res.trades:
            assert 0 < t.hold_days <= max_hold + 2

    def test_sell_date_after_buy_date(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        for t in res.trades:
            assert t.sell_date > t.buy_date

    def test_exit_distribution_sums_to_total(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(20, 300)))
        assert sum(res.exit_distribution.values()) == res.total_trades


class TestSummary:
    def test_summary_renders(self):
        bt = PortfolioBacktester()
        res = bt.run(add_signal_col(make_universe(10, 250)))
        text = res.summary()
        assert "累计收益率" in text
        assert "年化收益率" in text
        assert "最大回撤" in text


class TestEmptyInput:
    def test_empty_universe_returns_empty_result(self):
        bt = PortfolioBacktester()
        res = bt.run({})
        assert res.total_trades == 0
        assert res.final_equity == res.initial_cash
        assert res.total_return_pct == 0.0