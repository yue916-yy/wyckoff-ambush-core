# 归属与来源说明

## 原始作者与版权

本项目中的以下文件是 [`Lishoulan/lianghua`](https://github.com/Lishoulan/lianghua)
策略内核的提取与整理，**原作者版权归 Lishoulan 所有**：

| 本库文件 | 上游原始路径 | 改动 |
|----------|-------------|------|
| `wyckoff_ambush/v60_ambush_model.py` | `classic_ta/v60_ambush_model.py` | 仅 import 路径；移除未使用的 `json`/`time`/`Path` 导入 |
| `wyckoff_ambush/v61_ambush_model.py` | `classic_ta/v61_ambush_model.py` | 仅 import 路径 |
| `wyckoff_ambush/v62_ambush_model.py` | `classic_ta/v62_ambush_model.py` | 仅 import 路径 |
| `wyckoff_ambush/v63_ambush_model.py` | `classic_ta/v63_ambush_model.py` | 仅 import 路径 |
| `wyckoff_ambush/v64_ambush_model.py` | `classic_ta/v64_ambush_model.py` | 仅 import 路径 |
| `wyckoff_ambush/oamv_filter.py` | `ml_strategy/oamv_filter.py` | 仅 import 路径 |
| `wyckoff_ambush/backtest/order_execution.py` | `classic_ta/common/order_execution.py` | 仅位置调整 |

**信号检测逻辑本身未做修改**，以保证与上游行为一致。信号逻辑的测试验证见
`tests/test_signals.py`，其中包含了对上游逻辑不变量的断言
（如"有信号必有窗口内 SOS 锚定"）。

## 本库原创部分

以下文件为本次提取过程中**新写**的，版权归本仓库贡献者所有：

| 文件 | 说明 |
|------|------|
| `wyckoff_ambush/__init__.py` | 统一 API 导出与文档 |
| `wyckoff_ambush/backtest/__init__.py` | 回测模块导出 |
| `wyckoff_ambush/backtest/portfolio.py` | **完全重写**的组合级资金曲线回测器 |
| `tests/test_signals.py` | 信号逻辑测试 |
| `tests/test_backtest.py` | 回测口径与无前视测试 |
| `README.md`、`docs/UPSTREAM_AUDIT.md`、`pyproject.toml`、`.gitignore` | 文档与工程配置 |

`portfolio.py` 是全新实现，用于修正上游回测的收益口径错误、前视偏差和
资金约束缺失。设计依据见 `docs/UPSTREAM_AUDIT.md`。

## 许可证

MIT License, Copyright (c) 2025 lianghua（原始作者）

本仓库以 MIT 协议重新发布。上游为 MIT 协议，允许在保留版权声明的前提下
修改与再分发，本仓库遵循该条款。完整条款见 `LICENSE`。

## 上游致谢

感谢原作者 Lishoulan 的策略设计与实现。本仓库仅剥离策略内核，
并修正了审计中发现的评估层缺陷。

同时说明：审计中发现的问题（含上游 README 中无法由代码复现的业绩数字）
记录于 `docs/UPSTREAM_AUDIT.md`，这是为了避免误导使用者，
而非否定原作者的工作。策略思路（威科夫 SOS + VPA 情绪冰点 + 多层止损）
本身是成立的。