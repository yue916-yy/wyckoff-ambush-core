# 上游 lianghua 项目审计摘要

本库（`wyckoff-ambush-core`）是从 [`Lishoulan/lianghua`](https://github.com/Lishoulan/lianghua)
提取的**纯策略内核**。提取过程中对原仓库做了完整代码审计，发现若干影响结论可信度的问题。

本文档记录**哪些内容被保留、哪些被剔除、以及为什么**——目的是让使用本库的人
不要继承上游文档中的错误预期。

---

## 一、被剔除的内容及原因

| 模块 | 行数 | 剔除原因 |
|------|------|---------|
| `wechat_push/` | 1,610 | RLS 形同虚设（policy 限定 `service_role`，而该角色本身 BYPASSRLS）；订阅墙失效（`is_to_all: True` + 校验函数零调用）；推送幂等失效（代码用 `push_date` 但 schema 只有 `push_time`）；硬编码默认密钥 `WECHAT_TOKEN="lianghua2026"` / `PUSH_API_KEY="lianghua_push_2026"` 已进 Git 历史 |
| `classic_ta/stock_data_duckdb.py` 等数据层 | ~2,500 | DuckDB 单表无主键无事务；`volume` 列被 akshare（手）/ tushare（手）/ baostock（股）三条路径混写，**100 倍单位误差**；`_pending_write_queue` 是普通 `queue.Queue` 而扫描用 `ProcessPoolExecutor`，跨进程下缓存补全是死代码 |
| Docker / GitHub Actions | — | `Dockerfile` 未安装 cron 而 `docker-compose.yml` 调用 `crond` → 容器崩溃重启循环；compose 的 cron 无交易日判断，节假日照常推送 |
| `_temp_*.py` | 251 | 临时脚本，硬编码 `d:\Solo\TradingAgents\...` 绝对路径 |
| 对比/优化脚本 | ~1,800 | `compare_v63_v64*.py`、`oamv_threshold_optimizer.py`（阈值优化无样本外切分，过拟合风险） |

## 二、原文档声称但**未实现**的功能

| 声称 | 实际情况 |
|------|---------|
| 急跌保护（5 日跌幅中位数 < -5% 暂停买入 3 天，"触发 104 次"） | **全仓检索为零**，无任何实现。而这是其"胜率 32.6%→55.0%"的核心归因 |
| 维度六 UT/AD + VPA 派发退出 | `wyckoff_analysis.py`、`volume_price_analysis.py` **文件不存在**，被 `except ImportError: pass` 静默吞掉，`_has_utad`/`_has_vpa` 恒为 `False` |
| eltdx（通达信二进制协议）数据源 | 代码库中**不存在该依赖** |
| 日线 + 周线 OAMV 双重确认 | 实盘路径有，**回测路径只用了日线**（`backtest_ambush_v6.py:172`） |

## 三、回测业绩数字不可信

这是最关键的一点。

### 3.1 收益口径双重虚构

```python
# classic_ta/v60_ambush_model.py:473
total_profit = sum(t.profit_pct for t in trades)   # 百分比直接相加
```

复算上游报告的"累计 +1388.83% / 年化 +63.40%"：

```
869 笔 × 1.60% 平均收益 = 1390.40%        ← 这就是"累计 +1388.83%"
(1 + 13.9040) ^ (1/5.5) - 1 = 63.43%     ← 这就是"年化 +63.40%"
```

**即：把每笔收益率之和当累计收益，再把这个和当作复利基数开方根得年化。**

### 3.2 逐股独立回测，无组合资金约束

```python
# full_backtest_v64.py:42-68
for i, code in enumerate(all_codes, 1):
    df = get_stock_data_cached(code, ...)
    t64 = StatefulTradeBacktester_V64(df4, ...)   # 每只股票都从 10 万重新开始
```

仓位固定为 `initial_cash * 0.3`，且 `initial_cash` 恒为 10 万、永不随权益变化。
真实资金约束下的收益约为报告值的 **1/3（约 +417%）**，而这还建立在带前视偏差的成交价之上。

### 3.3 T+1 执行块的日内前视偏差

| 位置 | 问题 |
|------|------|
| `v63:142` + `:621` | 用 T+1 **全天 ATR**（含收盘）决定 T+1 **开盘**的仓位与止损倍数 |
| `v63:601-611` / `v64:866` | 限价成交用当日**最低价**判定 —— 事后才知道 |
| `v63:685` / `v64:960` | 同一根 K 线内先用**最高价**上移吊灯线，再拿当日**收盘价**判是否击穿 |
| `v63:324-330` | "VWAP" 实为**全历史累计 VWAP**（从数据起点 cumsum），结果依赖回测起点 |

### 3.4 未扣除交易成本

README 自述"869 笔估算费用约 -30%"，即原始业绩还要打七折。

---

## 四、本库的应对

| 上游问题 | 本库的处理 |
|----------|------------|
| `sum(profit_pct)` 收益口径 | `backtest/portfolio.py` 用**单一资金池 + 真实权益曲线**，总收益 = 期末/期初 − 1 |
| 年化二次虚构 | 按资金曲线起止日期做**几何年化** |
| 逐股独立回测 | `max_concurrent_positions` 限制同时持仓数，跨股票共享 cash |
| 仓位恒为 30% 初始资金 | 仓位基于**当前总权益**，真实复利 |
| 交易成本未计 | `CostModel` 双边扣除佣金/印花税/过户费 |
| T+1 日内前视 | 买入只用**开盘价**；卖出若开盘已破位按开盘价，否则收盘价；吊灯峰值只由已发生 K 线更新 |
| 样本外缺失 | `run(start=..., end=...)` 支持任意区间，便于训练/测试切分 |

并新增了防回归测试（`tests/test_backtest.py::TestNoLookahead`）：
篡改最后 30 天价格后，之前所有交易必须完全不变。

---

## 五、被保留且可用的部分

**策略信号内核是扎实的。** V6.0 的检测逻辑（`v60_ambush_model.py:235-241`）：

```python
df["ambush_signal"] = (
    sos_in_window     # 前置窗口内有 SOS 锚定（主力入场）
    & j_oversold      # J 值超卖（情绪冰点）
    & vol_shrink      # 缩量（抛压枯竭）
    & tiny_body       # 小实体（砸不动）
    & support_ok      # 均线托底
)
```

这是威科夫 LPS + VPA 量价 + 蜡烛图的正确组合，不是拍脑袋的参数拟合。
作者在 `v60:17-18` 明确标注了防泄漏设计（`shift(1).rolling()`），说明作者理解这个问题。

指标计算（`IndicatorCalcBase`）干净正确，KDJ / ATR / 双线体系实现无误。

**因此本库保留全部信号检测逻辑，并补充了测试验证其不变量**
（如"有信号必有窗口内 SOS 锚定"、"入场总分 = 四子分之和"）。

---

## 六、给使用者的建议

1. **不要引用上游的业绩数字做任何决策。** 用本库的 `PortfolioBacktester` 重新评估。
2. **务必做样本外切分。** 上游的阈值优化器在全样本上调参
   （`oamv_threshold_optimizer.py:187` 直接用同期收益），过拟合无法排除。
   建议训练 2021-2024、测试 2025-2026。
3. **数据源请自选。** 上游数据层存在单位污染，建议只取单一数据源并显式校验 volume 单位。
4. **本库不提供数据获取能力。** 这是刻意的——数据层是最容易出错、也最难复用的部分。

---

*审计基于上游提交 `0039afd`。所有结论均经命令行验证。*
*审计过程未修改上游仓库任何文件。*